#pragma once
#include <string>
 using namespace std;
class Cuenta
{
protected:
	double TipoDeInteres, saldo;
	string cuenta, nombre;
public:
	Cuenta();
	Cuenta (string nom,string cuen, double sal, double tipo);
	~Cuenta();
	void AsignarNombre (string nom);
	string ObtenerNombre();
	void AsignarCuenta (string cue);
	string ObtenerCuenta ();
	void AsignarTipoDeInteres(double tipo);
	double ObtenerTipoDeInteres();
	void Reintegro(double cantidad);
	void Ingreso(double cantidad);
	double Estado();
};

