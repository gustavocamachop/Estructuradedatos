#pragma once
#include "Cuenta.h"
class CuentaAhorro : public Cuenta 
{
private:
	double CuotaMantenimiento ;
public:
	CuentaAhorro(string nom,string cuen, double sal, double tipo, double mant);
	~CuentaAhorro(void);
	void AsignarCuotaMantenimiento(double cantidad);
	double ObtenerCuotaMantenimiento();
	void ReintegroCA(double cantidad);
};

