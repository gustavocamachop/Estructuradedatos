#include "StdAfx.h"
#include "CuentaAhorro.h"
#include <iostream>
 using namespace std;

CuentaAhorro::CuentaAhorro(string nom,string cuen, double sal, double tipo, double mant)
{ AsignarNombre(nom);
  AsignarCuenta(cuen);
  saldo = sal;
  TipoDeInteres = tipo;
  AsignarCuotaMantenimiento(mant);
}

CuentaAhorro::~CuentaAhorro(void)
{
}

void CuentaAhorro::AsignarCuotaMantenimiento(double cantidad)
{ if (cantidad < 0)
    { cout<<"Error : cuota de mantenimiento negativa ";
      return ;
    }
 CuotaMantenimiento = cantidad ;
}

double CuentaAhorro::ObtenerCuotaMantenimiento()
{return CuotaMantenimiento ; }