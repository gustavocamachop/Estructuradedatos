// Banco.Herencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Cuenta.h"
#include <iostream>
#include <string>
#include "conio.h"
 using namespace std;

void main ()
{ Cuenta C1;
  C1.AsignarNombre("Alicia");
  C1.AsignarCuenta("6333182");
  C1.AsignarTipoDeInteres(2.5);
  
  C1.Ingreso(30000);
  C1.Reintegro(10000);

  cout<<"\nNombre : "<<C1.ObtenerNombre()<<endl;
  cout<<"Nro de cuenta : "<<C1.ObtenerCuenta()<<endl;
  cout<<"Saldo : "<<C1.Estado()<<endl;
  cout<<"tipo de interes : "<<C1.ObtenerTipoDeInteres()<<endl;
	getch();
}

