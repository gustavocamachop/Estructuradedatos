#include "StdAfx.h"
#include "Cuenta.h"
#include <string>
#include <iostream>
 using namespace std;

Cuenta::Cuenta()
{ saldo = 0 ;
  TipoDeInteres = 0.0;
}

Cuenta::Cuenta(string nom,string cuen, double sal, double tipo)
{ AsignarNombre(nom);
  AsignarCuenta(cuen);
  saldo = sal;
  TipoDeInteres = tipo;
}

Cuenta::~Cuenta()
{
}

void Cuenta::AsignarNombre(string nom)
{ if (nom.length()==0)
    { cout<<"Error : cadena vacia "<<endl;
      return ;
    }
  nombre = nom;
}
string Cuenta::ObtenerNombre()
{ return nombre ;}

void Cuenta::AsignarCuenta(string cuen)
{ if (cuen.length()==0)
    { cout<<"Error : cadena vacia "<<endl;
      return ;
    }
 cuenta = cuen ;
}
string Cuenta::ObtenerCuenta()
{ return cuenta ;}

void Cuenta::AsignarTipoDeInteres(double tipo)
{ if (tipo<0)
    {cout<<"Error : tipo de interes negativo ";
     return ;
    }
 TipoDeInteres = tipo;
}
double Cuenta::ObtenerTipoDeInteres()
{ return TipoDeInteres ;}

void Cuenta::Reintegro(double cantidad)
{ if (saldo - cantidad < 0 )
    { cout<<"Error: no dispone de saldo "<<endl;
      return;
    }
  saldo = saldo - cantidad ;//
}

void Cuenta::Ingreso(double cantidad)
{ if (cantidad<0)
    { cout<<"Error cantidad negativa"<<endl;
      return ;
    }
  saldo = saldo + cantidad ;
}

double Cuenta::Estado()
{ return saldo;}
